public class Item {
    int price;
    int weight;
    public Item(){
        this(0,0);
    }
    public Item(int price,int weight){
        this.price=price;
        this.weight=weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

    public int getWeight() {
        return weight;
    }
}
