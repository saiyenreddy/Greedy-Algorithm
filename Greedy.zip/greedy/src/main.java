public class main {
    public static void main(String[] args) {
       Item[] objects = new Item[5];
       Item xbox = new Item(10,5);
       Item shoe = new Item(21,10);
        Item monstertruck = new Item(50,25);
        Item diamond = new Item(100,2);
        Item brick = new Item(100,500);
        objects[0] = xbox;
        objects[1] = shoe;
        objects[2] = monstertruck;
        objects[3] = diamond;
        objects[4] = brick;
        System.out.println(fillknapsack(40,objects) + "$ worth of items in the knapsack.");
    }
    public static int fillknapsack(int knapsackweight, Item[] objects){ // O(N^2)+O(N)
        objects=bubblesort(objects);
        int currentweight=0;
        int currentprice=0;
        for(int i = 0 ; i<objects.length;i++){
            if(currentweight+objects[i].getWeight()<knapsackweight){
                currentweight=currentweight+objects[i].getWeight();
                currentprice=currentprice+objects[i].getPrice();
            }
        }
        return currentprice;
    }
    public static Item[] bubblesort(Item [] arr){ //O(N^2)
        boolean checker = true;
        Item holder;
        while (checker==true){
            checker=false;
            for(int i =arr.length-2; i>=0; i--){
                if((double)arr[i].getPrice()/arr[i].getWeight()<(double)arr[i+1].getPrice()/arr[i+1].getWeight()){
                    holder=arr[i];
                    arr[i]=arr[i+1];
                    arr[i+1]=holder;
                    checker=true;
                }

            }
        }
        return arr;
    }
}
